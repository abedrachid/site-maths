/* Jongleur de symboles — continuous composition (Modernist DS) */

const W = 1080, H = 1080, GY = 880;
const BG = '#f3f2f2', INK = '#201e1d', GRID = 'rgba(32,30,29,0.09)';
const SYMS = ['f(x)', '√', '∫', 'Σ', 'π'];
const REST = [250, 385, 520, 655, 790];
const REST_Y = GY - 26;
const HX = 92, HY = GY - 300;

const MOTION = {
  enter: Easing.easeOutCubic,
  draw: Easing.easeInOutCubic,
  pop: Easing.easeOutBack,
};

const sat = (v) => clamp(v, 0, 1);
const lerp = (a, b, u) => a + (b - a) * u;

function juggle(t, i, n, P, cx, apex, wob) {
  const hands = [{ x: cx - HX, y: HY }, { x: cx + HX, y: HY }];
  const k = Math.floor((t / P - i) / n);
  const m = i + n * k;
  const local = t - m * P;
  const flight = (n - 1) * P;
  const hand = ((m % 2) + 2) % 2;
  const a = hands[hand], b = hands[1 - hand];
  if (local < flight) {
    const u = sat(local / flight);
    const ap = apex * (1 + wob * 0.22 * Math.sin(i * 2.1 + m * 1.7));
    return {
      x: lerp(a.x, b.x, u) + wob * 16 * Math.sin(t * 3.1 + i * 2),
      y: lerp(a.y, b.y, u) - 4 * ap * u * (1 - u) + wob * 10 * Math.sin(t * 2.3 + i),
      rot: (u - 0.5) * 46 * (hand ? 1 : -1),
      hand: -1,
    };
  }
  const w = sat((local - flight) / P);
  const h2 = 1 - hand;
  return { x: hands[h2].x, y: hands[h2].y + 30 * Math.sin(Math.PI * w), rot: 0, hand: h2 };
}

/* One pure function of authored time -> everything on screen. */
function sceneState(T, C, total) {
  const nSym = SYMS.length;
  const syms = [];
  const st = {
    cx: 540, crouch: 0, torso: 0, headTilt: 0,
    handL: { x: 540 - HX, y: HY }, handR: { x: 540 + HX, y: HY },
    parabola: 0, titleIn: 0,
  };

  const tFall = C.Chute + 0.6;
  const tPick = (i) => C.Ramasse + 0.25 + i * 0.52;
  const P_A = 0.42, P_B = 0.36;

  // ---------- 1. OUVERTURE + LANCER : 3 symbols, calm cascade
  if (T < tFall) {
    const start = C.Lancer - 0.5;
    for (let i = 0; i < nSym; i++) {
      if (i < 3) {
        const held = { x: 540 - HX + (i - 1) * 8, y: HY + 4 - i * 26, rot: 0, hand: 0 };
        const jp = juggle(Math.max(T, start), i, 3, P_A, 540, 200, 0.18);
        const u = sat((T - start) / 0.5);
        syms.push({
          x: lerp(held.x, jp.x, u), y: lerp(held.y, jp.y, u), rot: jp.rot * u,
          op: sat((T - (C.Ouverture + 1.4 + i * 0.18)) / 0.4), scale: 1, err: 0,
          hand: u > 0.9 ? jp.hand : 0,
        });
      } else {
        // the two extra symbols drop in from above just before the fall
        const t0 = C.Chute - 0.15 + (i - 3) * 0.18;
        const u = sat((T - t0) / 0.55);
        syms.push({
          x: 540 + (i === 3 ? -150 : 150), y: lerp(-90, HY - 210, MOTION.enter(u)),
          rot: lerp(-120, 0, u), op: u > 0 ? 1 : 0, scale: 1, err: sat((T - C.Chute) / 0.5),
          hand: -1,
        });
      }
    }
  }
  // ---------- 2. CHUTE : everything falls, scatters on the ground
  else if (T < C.Ramasse) {
    const pre = sceneState(tFall - 0.001, C, total).syms;
    for (let i = 0; i < nSym; i++) {
      const p = pre[i];
      const d = 0.62 + i * 0.06;
      const u = sat((T - tFall) / d);
      const e = u * u;
      const bounce = u >= 1 ? Math.exp(-(T - tFall - d) * 7) * 26 * Math.abs(Math.sin((T - tFall - d) * 13)) : 0;
      syms.push({
        x: lerp(p.x, REST[i], MOTION.enter(u)),
        y: lerp(p.y, REST_Y, e) - bounce,
        rot: lerp(p.rot, (i % 2 ? 1 : -1) * (14 + i * 5), u),
        op: 1, scale: 1, err: 1, hand: -1,
      });
    }
  }
  // ---------- 3. RAMASSE : he picks them up, one by one
  else if (T < C.Recommence) {
    for (let i = 0; i < nSym; i++) {
      const t0 = tPick(i);
      const u = sat((T - t0) / 0.45);
      const cxAt = REST[i] + 46;
      syms.push({
        x: lerp(REST[i], cxAt - 30, u),
        y: lerp(REST_Y, GY - 340, Easing.easeInCubic(u)),
        rot: lerp((i % 2 ? 1 : -1) * (14 + i * 5), 0, u),
        op: 1 - sat((u - 0.55) / 0.45), scale: lerp(1, 0.55, u), err: 1 - u, hand: -1,
      });
    }
  }
  // ---------- 4/5. RECOMMENCE -> RÉUSSITE : one continuous cascade of five
  else {
    const wob = interpolate(
      [C.Recommence, C.Recommence + 1.3, C.Reussite - 0.5, C.Reussite + 1.1],
      [1.5, 1.15, 0.95, 0], MOTION.draw)(Math.min(T, C.Signature));
    const apex = interpolate([C.Recommence, C.Reussite + 1], [215, 250], MOTION.draw)(Math.min(T, C.Signature));
    const tS = C.Signature;
    for (let i = 0; i < nSym; i++) {
      const jp = juggle(Math.min(T, tS), i, nSym, P_B, 540, apex, wob);
      const fade = sat((T - (C.Recommence + i * 0.12)) / 0.4);
      let x = jp.x, y = jp.y, rot = jp.rot, scale = lerp(0.6, 1, MOTION.enter(fade)), hand = jp.hand;
      if (T >= tS) {
        // symbols settle onto a drawn parabola
        const u = sat((T - tS - i * 0.09) / 0.85);
        const e = MOTION.pop(u);
        const tx = 150 + i * 195;
        const ty = 470 + 0.00135 * Math.pow(tx - 540, 2) - 120;
        x = lerp(jp.x, tx, e); y = lerp(jp.y, ty, e); rot = lerp(jp.rot, 0, u);
        scale = lerp(1, 1.15, e); hand = -1;
      }
      syms.push({ x, y, rot, op: fade, scale, err: 0, hand });
    }
  }

  // ---------- character pose
  if (T < C.Ramasse) {
    if (T >= tFall) {
      const u = sat((T - tFall) / 0.7);
      st.torso = lerp(0, 0.26, u);
      st.headTilt = lerp(0, 16, u);
      st.crouch = lerp(0, 22, u);
      st.handL = { x: 540 - HX - 26 * u, y: HY + 150 * u };
      st.handR = { x: 540 + HX + 26 * u, y: HY + 150 * u };
    }
  } else if (T < C.Recommence) {
    const keys = [C.Ramasse], vals = [540];
    for (let i = 0; i < nSym; i++) { keys.push(tPick(i)); vals.push(REST[i] + 46); }
    keys.push(C.Recommence - 0.25); vals.push(540);
    st.cx = interpolate(keys, vals, MOTION.draw)(T);
    let bend = 0, reach = null;
    for (let i = 0; i < nSym; i++) {
      const u = sat((T - (tPick(i) - 0.35)) / 0.8);
      const b = Math.sin(Math.PI * u) * (u > 0 && u < 1 ? 1 : 0);
      if (b > bend) { bend = b; reach = i; }
    }
    st.torso = 0.95 * bend;
    st.crouch = 58 * bend;
    st.handL = reach == null
      ? { x: st.cx - HX, y: HY + 60 }
      : { x: lerp(st.cx - HX, REST[reach] + 6, bend), y: lerp(HY + 60, REST_Y - 6, bend) };
    st.handR = { x: st.cx + HX + 34 * bend, y: HY + 70 + 40 * bend };
  }

  // hands follow whatever symbol is resting in them mid-cascade
  const inHand = [null, null];
  syms.forEach((s) => { if (s.hand === 0 || s.hand === 1) inHand[s.hand] = s; });
  if (T < tFall || T >= C.Recommence) {
    const base = [{ x: st.cx - HX, y: HY }, { x: st.cx + HX, y: HY }];
    const h = [0, 1].map((k) => (inHand[k] ? { x: inHand[k].x, y: inHand[k].y + 16 } : base[k]));
    st.handL = h[0]; st.handR = h[1];
    st.torso = 0.05 * Math.sin(T * 2.2);
    st.crouch = 6 * Math.sin(T * 4.4) + (T >= C.Reussite ? 5 * Math.sin(T * 6) : 0);
  }
  if (T >= C.Signature) {
    const u = sat((T - C.Signature) / 0.7);
    st.handL = { x: lerp(st.handL.x, 540 - 150, u), y: lerp(st.handL.y, HY - 90, u) };
    st.handR = { x: lerp(st.handR.x, 540 + 150, u), y: lerp(st.handR.y, HY - 90, u) };
    st.torso = lerp(st.torso, -0.05, u);
    st.crouch = lerp(st.crouch, -10, u);
    st.parabola = sat((T - C.Signature - 0.25) / 0.9);
    st.titleIn = sat((T - C.Signature - 0.5) / 0.7);
  }
  st.draw = sat((T - 0.15) / 1.5); // opening line-draw of the figure
  return { syms, ...st };
}

function joints(st) {
  const cx = st.cx, a = st.torso;
  const hip = { x: cx + Math.sin(a) * 12, y: GY - 210 + st.crouch };
  const sh = { x: hip.x + Math.sin(a) * 152, y: hip.y - Math.cos(a) * 152 };
  const head = { x: sh.x + Math.sin(a * 0.8) * 54, y: sh.y - Math.cos(a * 0.8) * 54 };
  const kneeDrop = st.crouch * 0.5;
  const legs = `M ${cx - 56} ${GY} L ${cx - 60} ${GY - 106 + kneeDrop} L ${hip.x} ${hip.y} L ${cx + 58} ${GY - 106 + kneeDrop} L ${cx + 54} ${GY}`;
  const elbow = (h) => ({ x: (sh.x + h.x) / 2 + (h.x - sh.x) * 0.05, y: (sh.y + h.y) / 2 + 30 });
  const eL = elbow(st.handL), eR = elbow(st.handR);
  const arms = `M ${st.handL.x} ${st.handL.y} L ${eL.x} ${eL.y} L ${sh.x} ${sh.y} L ${eR.x} ${eR.y} L ${st.handR.x} ${st.handR.y}`;
  const spine = `M ${hip.x} ${hip.y} L ${sh.x} ${sh.y}`;
  return { legs, arms, spine, head, a };
}

function Grid() {
  const v = [], h = [];
  for (let x = 90; x < W; x += 90) v.push(<line key={'v' + x} x1={x} y1="0" x2={x} y2={H} stroke={GRID} strokeWidth="1" />);
  for (let y = 90; y < H; y += 90) h.push(<line key={'h' + y} x1="0" y1={y} x2={W} y2={y} stroke={GRID} strokeWidth="1" />);
  return <g>{v}{h}</g>;
}

function Piece(props) {
  const { T, CUES, authoredTotal } = useComposition();
  const accent = props.accent || '#ec3013';
  const s = sceneState(T, CUES, authoredTotal);
  const j = joints(s);
  const cam = {
    k: interpolate(
      [0, CUES.Lancer, CUES.Chute, CUES.Chute + 1.1, CUES.Ramasse, CUES.Recommence, CUES.Reussite, CUES.Signature, authoredTotal],
      [1.02, 1.08, 1.0, 1.22, 1.18, 1.04, 0.96, 1.0, 1.0], MOTION.draw)(T),
    x: interpolate(
      [CUES.Ramasse, CUES.Recommence - 0.3, authoredTotal],
      [540, 540, 540], MOTION.draw)(T),
  };
  const camX = T >= CUES.Ramasse && T < CUES.Recommence ? s.cx : cam.x;
  const camY = interpolate(
    [0, CUES.Chute + 1.1, CUES.Ramasse, CUES.Recommence, authoredTotal],
    [560, 720, 700, 560, 540], MOTION.draw)(T);
  const globalOp = interpolate([0, 0.35, authoredTotal - 0.5, authoredTotal], [0, 1, 1, 0])(T);

  const figLen = 1400;
  const parabola = (() => {
    const pts = [];
    for (let x = 120; x <= 960; x += 20) pts.push(`${x},${(470 + 0.00135 * Math.pow(x - 540, 2) - 120).toFixed(1)}`);
    return 'M ' + pts.join(' L ');
  })();

  return (
    <div style={{ position: 'absolute', inset: 0, background: BG }}>
      <svg width="100%" height="100%" viewBox={`0 0 ${W} ${H}`} style={{ display: 'block', opacity: globalOp }}>
        <g transform={`translate(${W / 2} ${H / 2}) scale(${cam.k}) translate(${-camX} ${-camY})`}>
          <Grid />
          <line x1="0" y1={GY} x2={W} y2={GY} stroke={INK} strokeWidth="2" />
          <path d={parabola} fill="none" stroke={accent} strokeWidth="3"
                strokeDasharray="1500" strokeDashoffset={1500 * (1 - s.parabola)} opacity={s.parabola > 0 ? 1 : 0} />
          <g fill="none" stroke={INK} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"
             strokeDasharray={figLen} strokeDashoffset={figLen * (1 - MOTION.draw(s.draw))}>
            <path d={j.legs} />
            <path d={j.spine} />
            <path d={j.arms} />
          </g>
          <circle cx={j.head.x} cy={j.head.y} r="31" fill="none" stroke={INK} strokeWidth="6"
                  opacity={sat((s.draw - 0.55) / 0.3)} />
          {s.syms.map((sy, i) => (
            <text key={i} x={sy.x} y={sy.y} textAnchor="middle" dominantBaseline="central"
                  transform={`rotate(${sy.rot} ${sy.x} ${sy.y}) scale(1)`}
                  style={{
                    font: `700 ${Math.round(64 * sy.scale)}px Archivo, sans-serif`,
                    fill: sy.err > 0.5 ? accent : INK, opacity: sy.op,
                  }}>{SYMS[i]}</text>
          ))}
        </g>
        <g opacity={s.titleIn}>
          <rect x="96" y="150" width={520 * s.titleIn} height="6" fill={accent} />
          <text x="96" y="252" style={{ font: '800 76px Archivo, sans-serif', fill: INK, letterSpacing: '-2px' }}>RATER FAIT</text>
          <text x="96" y="336" style={{ font: '800 76px Archivo, sans-serif', fill: INK, letterSpacing: '-2px' }}>PARTIE DU</text>
          <text x="96" y="420" style={{ font: '800 76px Archivo, sans-serif', fill: INK, letterSpacing: '-2px' }}>
            CALCUL<tspan fill={accent}>.</tspan>
          </text>
          <text x="96" y="990" style={{ font: '600 26px Archivo, sans-serif', fill: INK, letterSpacing: '4px' }}>
            APPRENDRE · S'ENTRAÎNER · RÉUSSIR
          </text>
        </g>
      </svg>
      {props.captions && (
        <Captions
          items={[
            { at: CUES.Ouverture + 0.6, until: CUES.Lancer + 0.2, text: "Apprendre les maths, c'est jongler." },
            { at: CUES.Lancer + 0.5, until: CUES.Chute - 0.1, text: 'Trois symboles. Ça tient.' },
            { at: CUES.Chute + 0.7, until: CUES.Ramasse - 0.1, text: 'Deux de plus… et tout tombe.' },
            { at: CUES.Ramasse + 0.2, until: CUES.Recommence - 0.1, text: 'Il ramasse.' },
            { at: CUES.Recommence + 0.2, until: CUES.Reussite - 0.1, text: 'Il recommence.' },
            { at: CUES.Reussite + 0.4, until: CUES.Signature - 0.2, text: 'Et cette fois, ça tourne.' },
          ]}
          style={{
            left: '9%', right: '9%', bottom: '8%', textAlign: 'left',
            font: "600 34px Archivo, sans-serif", color: INK, textShadow: 'none',
            borderLeft: `6px solid ${accent}`, paddingLeft: '20px',
          }}
        />
      )}
    </div>
  );
}

function JugglePiece() {
  const [tw, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <CompositionStage width={W} height={H} bg={BG}
                        scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        <Piece accent={tw.accent} captions={tw.captions} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Contenu" />
        <TweakToggle label="Sous-titres" value={tw.captions} onChange={(v) => setTweak('captions', v)} />
        <TweakColor label="Accent" value={tw.accent}
                    options={['#ec3013', '#201e1d', '#1f6feb', '#0f8a4f']}
                    onChange={(v) => setTweak('accent', v)} />
        <TweakSection label="Édition" />
        <TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
}

window.JugglePiece = JugglePiece;
